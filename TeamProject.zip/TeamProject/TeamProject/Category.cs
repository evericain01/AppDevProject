﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProject
{
    public class Category
    {
        public string name { get; set; }
        public List<int> grades;
        public double average;
        public double totalCategoryGrade;
    }
}
