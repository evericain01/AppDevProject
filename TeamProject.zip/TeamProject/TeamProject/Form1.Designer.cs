﻿namespace TeamProject
{
    partial class courseChooserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.courseNoLabel = new System.Windows.Forms.Label();
            this.potentialCourseNo = new System.Windows.Forms.TextBox();
            this.showStudentsBtn = new System.Windows.Forms.Button();
            this.showCategoriesBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // courseNoLabel
            // 
            this.courseNoLabel.AutoSize = true;
            this.courseNoLabel.Location = new System.Drawing.Point(55, 9);
            this.courseNoLabel.Name = "courseNoLabel";
            this.courseNoLabel.Size = new System.Drawing.Size(83, 13);
            this.courseNoLabel.TabIndex = 0;
            this.courseNoLabel.Text = "Course Number:";
            // 
            // potentialCourseNo
            // 
            this.potentialCourseNo.Location = new System.Drawing.Point(47, 25);
            this.potentialCourseNo.Name = "potentialCourseNo";
            this.potentialCourseNo.Size = new System.Drawing.Size(100, 20);
            this.potentialCourseNo.TabIndex = 1;
            // 
            // showStudentsBtn
            // 
            this.showStudentsBtn.Location = new System.Drawing.Point(12, 62);
            this.showStudentsBtn.Name = "showStudentsBtn";
            this.showStudentsBtn.Size = new System.Drawing.Size(75, 23);
            this.showStudentsBtn.TabIndex = 2;
            this.showStudentsBtn.Text = "Students";
            this.showStudentsBtn.UseVisualStyleBackColor = true;
            this.showStudentsBtn.Click += new System.EventHandler(this.showStudentsBtn_Click);
            // 
            // showCategoriesBtn
            // 
            this.showCategoriesBtn.Location = new System.Drawing.Point(103, 62);
            this.showCategoriesBtn.Name = "showCategoriesBtn";
            this.showCategoriesBtn.Size = new System.Drawing.Size(75, 23);
            this.showCategoriesBtn.TabIndex = 3;
            this.showCategoriesBtn.Text = "Categories";
            this.showCategoriesBtn.UseVisualStyleBackColor = true;
            this.showCategoriesBtn.Click += new System.EventHandler(this.showCategoriesBtn_Click);
            // 
            // courseChooserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(191, 114);
            this.Controls.Add(this.showCategoriesBtn);
            this.Controls.Add(this.showStudentsBtn);
            this.Controls.Add(this.potentialCourseNo);
            this.Controls.Add(this.courseNoLabel);
            this.Name = "courseChooserForm";
            this.Text = "Course Viewer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label courseNoLabel;
        private System.Windows.Forms.TextBox potentialCourseNo;
        private System.Windows.Forms.Button showStudentsBtn;
        private System.Windows.Forms.Button showCategoriesBtn;
    }
}

